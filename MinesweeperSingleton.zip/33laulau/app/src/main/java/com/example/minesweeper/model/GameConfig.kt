package com.example.minesweeper.model

object GameConfig {
    const val NUMBER_OF_ROWS = 10
    const val NUMBER_OF_COLUMNS = 10
}